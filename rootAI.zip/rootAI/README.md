step 1 -> npm i     
step 2 -> add your api key to .env.local file ( create a new file if it doen't exists)   
step 3 -> npm run dev  




To get api key ( GEMINI GOOGLE BARD ) -   https://ai.google.dev/
